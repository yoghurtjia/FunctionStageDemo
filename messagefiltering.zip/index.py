# -*- coding:utf-8 -*-
import json
import jieba
import os
import sys

reload(sys)  
sys.setdefaultencoding('utf-8')

def is_ok_publish(body, over = 0.1):
    '''
    body中敏感词数量超过10%，此消息不能发出
    '''
    words = list(jieba.cut(body))
    #print("*****body:")
    #print(words)
    filename = os.environ.get('RUNTIME_CODE_ROOT') + '/sensitivewords.txt'
    with open(filename)as file:
        sensitive_words = file.read().decode('gbk').split('\r\n')
    #print("*****sensitive_words:")
    #print(sensitive_words)
    num = 0
    for each in (set(words) & set(sensitive_words)):
        #print each
        num = num + 1
    #print(num)
    length = len(set(words))
    #print(length)
    rate = float(num)/length
    #print(rate)
    if(rate >= over):
        return False
    return True        #可以出版

def handler (event, context):

    msg = event['Messages'] 
    body = msg[0]["Body"]
    
    #body = context.getUserData('content')
    #print(type(body))
    #print(body)
    #print("****begin cut")
    #words = list(jieba.cut(body))
    #print(','.join(words))
    #print("****finish cut")
    flag = is_ok_publish(body)
    if (flag == True):
        print("message normal")
        print("ok to publish")
        print(body)
        return "ok to publish"
    else:
        print("sensitive words occurs many times")
        print(u"消息中存在太多的敏感词，禁止发布")
        print("can not allow to publish")
        return "can not allow to publish"
    return "^_^"


if __name__ == '__main__':
    event = {"QueueID": "e10b8e7c-3d4f-4251-967f-8421f104a9d2", "Tag": "latest", "Messages": [{"Body": "文革法轮功中国", "Attributes": {"ip": "192", "name": "asdasd"}}], "ConsumerGroupID": "g-c7e7b2e9-e905-4ac0-a5c3-fc944b8e2d5a"}
    handler(event, 0)
    